// js/api.js
export class JiraClient {
    constructor(config) {
        this.host = config.host;
        this.email = config.email;
        this.token = config.token;
        this.mode = config.mode || 'live';
        this.users = config.users || [];
        this.projects = config.projects || [];
        console.log(`%c JiraClient Pathfinder (v24) - Subordinate Focus`, "color: #ef4444; font-weight: bold; font-size: 1.2em;");
    }

    getAuthHeader() { return 'Basic ' + btoa(`${this.email}:${this.token}`); }

    async fetchData(period = '30d') {
        if (this.mode === 'mock') return { issues: [] };

        const buildJql = () => {
            const parts = [];
            const cleanPro = this.projects.map(p => p.trim()).filter(p => p.length > 0);
            if (cleanPro.length > 0) {
                parts.push(`project IN (${cleanPro.map(p => `"${p}"`).join(',')})`);
            }
            parts.push(`updated >= -${period}`);
            return parts.join(' AND ') + ' ORDER BY updated DESC';
        };

        const allIssues = [];
        let startAt = 0;
        const maxResults = 100;
        const targetLimit = 2000;

        const fetchSubset = async (jql, offset) => {
            // Added emailAddress to fields
            const params = new URLSearchParams({
                jql: jql,
                startAt: offset,
                maxResults: maxResults,
                fields: 'summary,status,assignee,created,updated,resolutiondate,duedate,project,emailAddress'
            });
            const url = `${this.host}/rest/api/3/search/jql?${params.toString()}`;
            const proxyUrl = `/api/proxy?url=${encodeURIComponent(url)}`;

            const res = await fetch(proxyUrl, {
                headers: { 'Authorization': this.getAuthHeader(), 'Accept': 'application/json' }
            });

            if (res.status === 401) { alert("401 Unauthorized!"); throw new Error("401"); }
            if (!res.ok) {
                const text = await res.text();
                throw new Error(`Jira Error ${res.status}: ${text}`);
            }
            return await res.json();
        };

        try {
            const currentJql = buildJql();
            console.log("Starting Subordinate Scan (2000 tasks)...");

            while (allIssues.length < targetLimit) {
                const updateStatus = document.getElementById('syncButton');
                if (updateStatus) updateStatus.innerText = `Fetch ${allIssues.length}...`;

                const data = await fetchSubset(currentJql, startAt);
                if (!data.issues || data.issues.length === 0) break;

                allIssues.push(...data.issues);
                if (data.issues.length < maxResults) break;
                startAt += maxResults;
            }

            return { issues: allIssues, total: allIssues.length };
        } catch (e) {
            console.error("fetchData failed:", e);
            throw e;
        }
    }

    async hydrateIssues(shortIssues) {
        const valid = [];
        for (const s of shortIssues) {
            try {
                const res = await fetch(`/api/proxy?url=${encodeURIComponent(this.host + '/rest/api/3/issue/' + s.key + '?expand=changelog')}`, {
                    headers: { 'Authorization': this.getAuthHeader() }
                });
                if (res.ok) valid.push(await res.json());
            } catch (e) { }
            if (valid.length >= 30) break;
        }
        return { issues: valid, total: valid.length };
    }

    async getDbData(period = '30d') {
        const res = await fetch(`/api/db/issues?days=${parseInt(period) || 30}`);
        return res.ok ? await res.json() : { issues: [] };
    }

    async syncData(issues) {
        if (!issues || issues.length === 0) return;
        const chunkSize = 100;
        for (let i = 0; i < issues.length; i += chunkSize) {
            const chunk = issues.slice(i, i + chunkSize);
            const res = await fetch('/api/db/sync', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ issues: chunk })
            });
            if (!res.ok) {
                const txt = await res.text();
                throw new Error(`Sync Failed at offset ${i}: ${txt}`);
            }
        }
    }
}
