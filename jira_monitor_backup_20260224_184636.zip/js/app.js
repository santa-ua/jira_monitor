// js/app.js
import { JiraClient } from './api.js';

const defaultConfig = { host: '', email: '', token: '', mode: 'live', users: [], projects: [], slaThreshold: 24 };
let config = JSON.parse(localStorage.getItem('jiraMonitorConfig')) || defaultConfig;
let client = new JiraClient(config);
let charts = {};
let currentIssues = [];
let rowsPerPage = 10;
let currentPage = 1;
let showOverdueOnly = false;

const CLOSED_STATUSES = ['Closed', 'Done', 'Resolved', 'Ready for QA', 'QA Passed', 'Finished', 'Завершено', 'Выполнено'];
const isClosed = (s) => CLOSED_STATUSES.includes(s);

function getBestDate(i) {
    const rd = i.fields?.resolutiondate || i.resolutiondate;
    if (rd) return new Date(rd);
    const st = i.fields?.status?.name || i.status;
    if (st && isClosed(st)) return new Date(i.fields?.updated || i.updated);
    return null;
}

function getIssueProject(i) {
    let p = i.fields?.project?.key || i.project;
    if (!p || p === 'Unknown') {
        if (i.key && i.key.includes('-')) p = i.key.split('-')[0];
    }
    return p || 'Unknown';
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("%c Dashboard v24: Subordinate Filter", "color: #10b981; font-weight: bold; font-size: 1.5em;");
    setupNavigation();
    loadSettingsIntoUI();
    setupSettingsForm();
    setupPagination();
    setupTimeRange();
    setupUserFilter();
    setupStatusFilter();
    setupSyncButton();
    setupOverdueFilter();
    updateModeBadge();
    loadDashboard();
});

function setupOverdueFilter() {
    const container = document.querySelector('.header-right');
    if (!container) return;
    let chk = document.getElementById('overdueOnlyLabel');
    if (!chk) {
        chk = document.createElement('label');
        chk.id = 'overdueOnlyLabel';
        chk.style.cssText = 'margin-right: 15px; color: #ef4444; font-weight: bold; cursor: pointer; display: flex; align-items: center;';
        chk.innerHTML = `<input type="checkbox" id="overdueOnly" style="margin-right: 5px;"> Overdue Only`;
        container.insertBefore(chk, container.firstChild);
    }
    document.getElementById('overdueOnly').onchange = (e) => {
        showOverdueOnly = e.target.checked;
        loadDashboard();
    };
}

async function loadDashboard(forceRefresh = false) {
    const period = document.getElementById('timeRange')?.value || '30d';
    const selectedUser = document.getElementById('userFilter')?.value || 'all';
    const selectedStatus = document.getElementById('statusFilter')?.value || 'all';

    try {
        if (forceRefresh) {
            const btn = document.getElementById('syncButton');
            if (btn) btn.innerText = 'Syncing...';
            try {
                const data = await client.fetchData(period);
                if (data.issues && data.issues.length > 0) {
                    await client.syncData(data.issues);
                    const hData = await client.hydrateIssues(data.issues.slice(0, 30));
                    if (hData.issues) await client.syncData(hData.issues);
                    alert(`Success: Synced ${data.issues.length} issues!`);
                } else {
                    alert("No issues found in Jira for this period.");
                }
            } catch (e) {
                console.error("Sync Error:", e);
                alert("SYNC ERROR: " + e.message);
            } finally {
                if (btn) btn.innerText = 'Sync Jira';
            }
        }

        const dbRes = await client.getDbData(period);
        const issues = dbRes.issues || [];
        updateDashboardUI(issues, selectedUser, selectedStatus);
    } catch (e) {
        console.error("Dashboard Load Error:", e);
    }
}

function updateDashboardUI(issues, selectedUser, selectedStatus) {
    const now = new Date();
    let filtered = issues;

    // 1. PROJECT FILTER
    const trackedProjects = config.projects.map(p => p.trim()).filter(p => p.length > 0);
    if (trackedProjects.length > 0) {
        filtered = filtered.filter(i => trackedProjects.includes(getIssueProject(i)));
    }

    const subordinates = config.users.map(u => u.trim().toLowerCase()).filter(u => u.length > 0);
    if (subordinates.length > 0) {
        filtered = filtered.filter(i => {
            const name = (i.fields?.assignee?.displayName || i.assignee || '').toLowerCase();
            const email = (i.fields?.assignee?.emailAddress || '').toLowerCase();
            return subordinates.some(s => {
                if (name.includes(s) || email.includes(s)) return true;
                if (s.includes('@')) {
                    const prefix = s.split('@')[0];
                    if (name.includes(prefix)) return true;
                    if (prefix.includes('.')) {
                        const firstLast = prefix.replace('.', ' ');
                        if (name.includes(firstLast)) return true;
                    }
                }
                return false;
            });
        });
    }

    // 3. Dynamic Status Filter
    const statusSel = document.getElementById('statusFilter');
    if (statusSel) {
        const ss = new Set();
        filtered.forEach(i => {
            const s = i.fields?.status?.name || i.status;
            if (s) ss.add(s);
        });
        const curS = statusSel.value;
        while (statusSel.options.length > 1) statusSel.remove(1);
        Array.from(ss).sort().forEach(s => {
            const opt = document.createElement('option');
            opt.value = opt.innerText = s;
            if (s === curS) opt.selected = true;
            statusSel.appendChild(opt);
        });
    }

    // 4. Dynamic User Filter (Only showing subordinates if list is set)
    const userSel = document.getElementById('userFilter');
    if (userSel) {
        const us = new Set();
        filtered.forEach(i => {
            const u = i.fields?.assignee?.displayName || i.assignee || 'Unassigned';
            if (u) us.add(u);
        });
        const curU = userSel.value;
        while (userSel.options.length > 1) userSel.remove(1);
        Array.from(us).sort().forEach(u => {
            const opt = document.createElement('option');
            opt.value = opt.innerText = u;
            if (u === curU) opt.selected = true;
            userSel.appendChild(opt);
        });
    }

    // 5. Advanced UI Filters
    if (showOverdueOnly) {
        filtered = filtered.filter(i => {
            const sName = i.fields?.status?.name || i.status;
            const cl = isClosed(sName) || !!(i.fields?.resolutiondate || i.resolutiondate);
            if (cl) return false;
            const due = i.fields?.duedate ? new Date(i.fields.duedate) : null;
            return due && due < now;
        });
    }

    if (selectedUser !== 'all') {
        filtered = filtered.filter(i => {
            const u = (i.fields?.assignee?.displayName || i.assignee || 'Unassigned').toLowerCase();
            return u.includes(selectedUser.toLowerCase());
        });
    }

    const sFilter = document.getElementById('statusFilter').value;
    const finalIssues = sFilter === 'all' ? filtered : filtered.filter(i => (i.fields?.status?.name || i.status) === sFilter);
    processAndRender(finalIssues, filtered);
}

function processAndRender(tableIssues, kpiIssues) {
    const now = new Date();
    const tableData = tableIssues.map(i => {
        const s = i.fields?.status?.name || i.status || 'Unknown';
        const cl = isClosed(s) || !!(i.fields?.resolutiondate || i.resolutiondate);
        const due = i.fields?.duedate ? new Date(i.fields.duedate) : null;
        return {
            key: i.key, summary: i.fields?.summary || i.summary || '',
            assignee: i.fields?.assignee?.displayName || i.assignee || 'Unassigned',
            created: i.fields?.created ? new Date(i.fields.created) : (i.created ? new Date(i.created) : null),
            duedate: due,
            statusBadge: cl ? 'success' : (['In Progress', 'Development', 'Review', 'Testing'].includes(s) ? 'warning' : 'danger'),
            statusText: s,
            isOverdue: !cl && due && due < now
        };
    });

    renderCharts(kpiIssues);
    renderTable(tableData);
    renderUserStats(kpiIssues);
}

function renderCharts(issues) {
    if (issues) currentIssues = issues;
    const canvas1 = document.getElementById('closureChart');
    const canvas2 = document.getElementById('statusChart');
    if (!canvas1 || !canvas2) return;
    if (!currentIssues || currentIssues.length === 0) {
        if (charts.closure) charts.closure.destroy();
        if (charts.status) charts.status.destroy();
        return;
    }

    const period = document.getElementById('timeRange')?.value || '30d';
    const labels = [];
    const buckets = [];
    const now = new Date();
    const limit = period === '7d' ? 7 : (period === '1d' ? 24 : 30);

    for (let i = limit - 1; i >= 0; i--) {
        const d = new Date(now);
        if (period === '1d') {
            d.setHours(now.getHours() - i, 0, 0, 0);
            labels.push(d.getHours() + ':00');
            buckets.push({ h: d.getHours(), d: d.getDate() });
        } else {
            d.setDate(now.getDate() - i);
            if (period === '7d' && (d.getDay() === 0 || d.getDay() === 6)) continue;
            labels.push(d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }));
            buckets.push({ time: new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() });
        }
    }

    const curators = [...new Set(currentIssues.map(i => i.fields?.assignee?.displayName || i.assignee || 'Unassigned'))].sort();
    const colors = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#3b82f6', '#8b5cf6', '#ec4899'];

    const datasets = curators.map((cur, idx) => {
        const data = buckets.map(b => {
            return currentIssues.filter(i => {
                const u = i.fields?.assignee?.displayName || i.assignee || 'Unassigned';
                if (u !== cur) return false;
                const rD = getBestDate(i);
                if (!rD) return false;
                if (period === '1d') return rD.getHours() === b.h && rD.getDate() === b.d;
                return new Date(rD.getFullYear(), rD.getMonth(), rD.getDate()).getTime() === b.time;
            }).length;
        });
        return { label: cur, data: data, backgroundColor: colors[idx % colors.length] };
    });

    if (charts.closure) charts.closure.destroy();
    charts.closure = new Chart(canvas1, {
        type: 'bar',
        data: { labels, datasets },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { title: { display: true, text: 'Resolutions' } },
            scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });

    const counts = {};
    currentIssues.forEach(i => {
        const s = i.fields?.status?.name || i.status || 'Unknown';
        counts[s] = (counts[s] || 0) + 1;
    });
    if (charts.status) charts.status.destroy();
    charts.status = new Chart(canvas2, {
        type: 'doughnut',
        data: { labels: Object.keys(counts), datasets: [{ data: Object.values(counts), backgroundColor: colors }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '70%' }
    });
}

function renderTable(data) {
    const body = document.getElementById('transitionsTableBody');
    if (!body) return;
    body.innerHTML = '';
    const start = (currentPage - 1) * rowsPerPage;
    data.slice(start, start + rowsPerPage).forEach(item => {
        const tr = document.createElement('tr');
        if (item.isOverdue) tr.style.borderLeft = '4px solid #ef4444';
        tr.innerHTML = `<td>${item.key}</td><td class="truncate" title="${item.summary}">${item.summary}</td><td>${item.assignee}</td><td>${item.created?.toLocaleDateString()}</td><td style="${item.isOverdue ? 'color: #ef4444; font-weight: bold;' : ''}">${item.duedate?.toLocaleDateString() || '-'}</td><td><span class="badge ${item.statusBadge}">${item.statusText}</span></td>`;
        body.appendChild(tr);
    });
}

function renderUserStats(issues) {
    const stats = {};
    const now = new Date();
    const tS = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yS = tS - 86400000;

    issues.forEach(i => {
        const u = i.fields?.assignee?.displayName || i.assignee || 'Unassigned';
        if (!stats[u]) stats[u] = { t: 0, p: 0, y: 0, ip: 0, o: 0, s: 0 };
        const sName = i.fields?.status?.name || i.status || 'Unknown';
        const cl = isClosed(sName) || !!(i.fields?.resolutiondate || i.resolutiondate);
        if (cl) {
            stats[u].p++;
            const rd = getBestDate(i);
            if (rd) {
                const rTS = new Date(rd.getFullYear(), rd.getMonth(), rd.getDate()).getTime();
                if (rTS === tS) stats[u].t++;
                else if (rTS === yS) stats[u].y++;
            }
        } else {
            if (['In Progress', 'Development', 'Review', 'Testing'].includes(sName)) stats[u].ip++;
            const due = i.fields?.duedate ? new Date(i.fields.duedate) : null;
            if (due && due < now) stats[u].o++;
            const upd = new Date(i.fields?.updated || i.updated);
            if (upd && (now - upd) / 86400000 > 5) stats[u].s++;
        }
    });

    const tb = document.getElementById('userStatsBody');
    if (!tb) return;
    tb.innerHTML = '';
    Object.entries(stats).sort((a, b) => b[1].t - a[1].t).forEach(([u, m]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${u}</td><td><span class="badge ${m.t > 0 ? 'success' : ''}">${m.t}</span></td><td><span class="badge">${m.p}</span></td><td>${m.y}</td><td>${m.ip}</td><td><span class="badge ${m.o > 0 ? 'danger' : ''}">${m.o}</span></td><td><span class="badge ${m.s > 0 ? 'warning' : ''}">${m.s}</span></td>`;
        tb.appendChild(tr);
    });
}

function updateModeBadge() {
    const b = document.getElementById('modeBadge');
    if (b) {
        b.innerText = config.mode === 'live' ? 'LIVE' : 'MOCK';
        b.className = config.mode === 'live' ? 'badge success' : 'badge warning';
    }
}

function setupNavigation() {
    const views = { dashboard: document.getElementById('dashboard-view'), settings: document.getElementById('settings-view') };
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            Object.values(views).forEach(v => v?.classList.remove('active'));
            if (views[btn.dataset.tab]) views[btn.dataset.tab].classList.add('active');
            if (btn.dataset.tab === 'dashboard' && currentIssues.length) setTimeout(() => renderCharts(currentIssues), 100);
        };
    });
}

function loadSettingsIntoUI() {
    document.getElementById('jiraHost').value = config.host || '';
    document.getElementById('jiraEmail').value = config.email || '';
    document.getElementById('jiraToken').value = config.token || '';
    if (document.getElementById('appMode')) document.getElementById('appMode').value = config.mode || 'live';
    document.getElementById('trackedUsers').value = config.users.join(', ');
    document.getElementById('trackedProjects').value = config.projects.join(', ');
}

function setupSettingsForm() {
    document.getElementById('saveSettings')?.addEventListener('click', () => {
        const h = document.getElementById('jiraHost').value.trim();
        config = {
            host: h.endsWith('/') ? h.slice(0, -1) : h,
            email: document.getElementById('jiraEmail').value.trim(),
            token: document.getElementById('jiraToken').value.trim(),
            mode: document.getElementById('appMode')?.value || 'live',
            users: document.getElementById('trackedUsers').value.split(/[,\n]+/).map(s => s.trim()).filter(s => s.length > 0),
            projects: document.getElementById('trackedProjects').value.split(/[,\n]+/).map(s => s.trim()).filter(s => s.length > 0),
            slaThreshold: 24
        };
        localStorage.setItem('jiraMonitorConfig', JSON.stringify(config));
        client = new JiraClient(config);
        alert('Settings Saved!');
        loadDashboard();
    });
}

function setupPagination() {
    document.getElementById('prevPage')?.addEventListener('click', () => { if (currentPage > 1) { currentPage--; loadDashboard(); } });
    document.getElementById('nextPage')?.addEventListener('click', () => { currentPage++; loadDashboard(); });
}

function setupTimeRange() { document.getElementById('timeRange')?.addEventListener('change', () => loadDashboard()); }
function setupUserFilter() { document.getElementById('userFilter')?.addEventListener('change', () => loadDashboard()); }
function setupStatusFilter() { document.getElementById('statusFilter')?.addEventListener('change', () => loadDashboard()); }
function setupSyncButton() { document.getElementById('syncButton')?.addEventListener('click', () => loadDashboard(true)); }
